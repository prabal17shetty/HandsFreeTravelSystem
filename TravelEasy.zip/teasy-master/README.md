               Travel Easy with Python & Firebase
*************************************************************************


login.py - Login Page  -calls init.py -check Database every five minutes

mains.py -Main page - call cam1.py & cam2.py

Cam1.py & Cam2.py -To run Both Camera

encode_faces.py - To Run Encodings

encodings.pickle  -Encoded Image Pickle File

************************************************************************
                     Folder Information

firebase -To download image from cloud store

dataset -To hold user images for encodings  

account -To hold the user trave information in json file

unknown - To hold the unknown user iamges & deletes everyday at 6:00 Pm

 
